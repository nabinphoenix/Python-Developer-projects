# main.py
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta
from typing import Optional, List, Any, Dict

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, Field
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ReturnDocument
from passlib.context import CryptContext
from jose import JWTError, jwt

# ---------- Load env ----------
load_dotenv()
MONGODB_URL = os.getenv("MONGODB_URL")
SECRET_KEY = os.getenv("SECRET_KEY", "mysecret")  # use env variable in prod
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

DB_NAME = "todo_app"
TASKS_COLL = "tasks"
COUNTERS_COLL = "counters"
USERS_COLL = "users"

app = FastAPI(title="To-Do List API (MongoDB + FastAPI)")


# ---------- Security setup ----------
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password):
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


# ---------- Pydantic models ----------
class Task(BaseModel):
    id: Optional[int] = Field(None, alias="_id")
    title: str
    description: Optional[str] = None
    completed: bool = False
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    owner: str  # username of creator

    class Config:
        populate_by_name = True


class TaskRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=2000)
    completed: Optional[bool] = False


class User(BaseModel):
    username: str
    password: str


class UserInDB(User):
    hashed_password: str


class Token(BaseModel):
    access_token: str
    token_type: str


# ---------- DB setup ----------
mongo_client = AsyncIOMotorClient(MONGODB_URL)
db = mongo_client[DB_NAME]
tasks = db[TASKS_COLL]
counters = db[COUNTERS_COLL]
users = db[USERS_COLL]


# ---------- Helper ----------
async def get_next_sequence(name: str) -> int:
    doc = await counters.find_one_and_update(
        {"_id": name},
        {"$inc": {"seq": 1}},
        upsert=True,
        return_document=ReturnDocument.AFTER,
    )
    return int(doc["seq"])


async def get_user(username: str) -> Optional[Dict[str, Any]]:
    return await users.find_one({"username": username})


async def authenticate_user(username: str, password: str):
    user = await get_user(username)
    if not user:
        return False
    if not verify_password(password, user["hashed_password"]):
        return False
    return user


async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = await get_user(username)
    if user is None:
        raise credentials_exception
    return user


# ---------- Auth Endpoints ----------
@app.post("/register")
async def register(user: User):
    existing = await users.find_one({"username": user.username})
    if existing:
        raise HTTPException(status_code=400, detail="Username already registered")
    hashed_pw = get_password_hash(user.password)
    await users.insert_one({"username": user.username, "hashed_password": hashed_pw})
    return {"msg": "User registered successfully"}


@app.post("/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["username"]}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}


# ---------- CRUD Endpoints ----------
@app.post("/tasks", response_model=Task, response_model_by_alias=True)
async def create_task(payload: TaskRequest, current_user: dict = Depends(get_current_user)):
    new_id = await get_next_sequence(TASKS_COLL)
    now = datetime.utcnow()
    doc = {
        "_id": new_id,
        "title": payload.title,
        "description": payload.description,
        "completed": payload.completed if payload.completed is not None else False,
        "created_at": now,
        "updated_at": now,
        "owner": current_user["username"],
    }
    await tasks.insert_one(doc)
    return doc


@app.get("/tasks", response_model=List[Task], response_model_by_alias=True)
async def list_tasks(current_user: dict = Depends(get_current_user)):
    docs = await tasks.find({"owner": current_user["username"]}).sort("_id", 1).to_list(length=10000)
    return docs


@app.get("/tasks/{task_id}", response_model=Task, response_model_by_alias=True)
async def get_task(task_id: int, current_user: dict = Depends(get_current_user)):
    doc = await tasks.find_one({"_id": task_id, "owner": current_user["username"]})
    if not doc:
        raise HTTPException(status_code=404, detail="Task not found")
    return doc


@app.put("/tasks/{task_id}", response_model=Task, response_model_by_alias=True)
async def update_task(task_id: int, payload: TaskRequest, current_user: dict = Depends(get_current_user)):
    updates: Dict[str, Any] = {
        k: v for k, v in payload.dict(exclude_unset=True).items()
    }
    if not updates:
        doc = await tasks.find_one({"_id": task_id, "owner": current_user["username"]})
        if not doc:
            raise HTTPException(status_code=404, detail="Task not found")
        return doc

    updates["updated_at"] = datetime.utcnow()
    doc = await tasks.find_one_and_update(
        {"_id": task_id, "owner": current_user["username"]},
        {"$set": updates},
        return_document=ReturnDocument.AFTER,
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Task not found")
    return doc


@app.delete("/tasks/{task_id}")
async def delete_task(task_id: int, current_user: dict = Depends(get_current_user)):
    res = await tasks.delete_one({"_id": task_id, "owner": current_user["username"]})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Task not found")
    return JSONResponse(status_code=204, content=None)
