def view_course():
    with open('course.txt', 'r') as fp:
        if len(fp.readlines()) == 0:
            print('Course is not added.')
            return True
        fp.seek(0)
        content = fp.read()
        content_list = content.split('\n')
        print('\nCourse details :')
        for i in content_list:
            sub_and_topics = i.split(':')
            topic = sub_and_topics[1].split(',')
            print(f'Subject name:{sub_and_topics[0]} ')
            print('\tTopics:', end=" ")
            for t in topic:
                print(t, end="  ")
            print('\n')
        return content_list

