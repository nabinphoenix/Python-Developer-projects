from validations import *
from extras import * 

def admin_login():
    print('*'*30)
    loginAttempts = 0
    while loginAttempts < 3:
        username = input('Enter username:')
        password = input('Enter password:')
        if username == 'admin07' and password == 'Admin@123':
            print('Congratulations, You have successful login!!!')
            return True
        else:
            print('Invalid username or password!!!, Try again')
            loginAttempts += 1
    print('Login failed')
    return False

def view_lecturer():
    with open('lecturer_details.txt', 'r') as fp:
        ID = input('Enter the ID of that lecturer:')
        boolean_value = False
        for i in fp:
            if i.split()[-3] == ID:
                content = i
                boolean_value = True
        if not boolean_value:
            print('ID does not exist.')
            return
        details = content.split()
        print(f'\nFollowing are the details of Lecturer {ID}:')
        print(f'First name: {details[0]}')
        print(f'Last name: {details[1]}')
        print(f'Address: {details[2]}')
        print(f'Contact no: {details[3]}')
        print(f'Email: {details[4]}')
        print(f'DOB: {details[5]}')
        print(f'Age: {details[6]}')
        print(f'Citizenship_no: {details[7]}')
        print(f'ID: {details[8]}')
        print(f'Username: {details[9]}')
        print(f'Password: {details[10]}')

def add_new_lecturer():
    lecturer_details = []
    
    while True:
        first_name = input("Enter lecturer's first name: ")
        if is_valid_name(first_name):
            lecturer_details.append(first_name)
            break
        else:
            print("Invalid first name. Please enter alphabetic characters only.")
    
    while True:
        last_name = input("Enter lecturer's last name: ")
        if is_valid_name(last_name):
            lecturer_details.append(last_name)
            break
        else:
            print("Invalid last name. Please enter alphabetic characters only.")
    
    while True:
        address = input("Enter lecturer's address: ")
        if is_valid_address(address):
            lecturer_details.append(address)
            break
        else:
            print("Invalid address. Please enter an address containing both letters and numbers.")
    
    while True:
        contact_no = input("Enter lecturer's contact no: ")
        if is_valid_contact_number(contact_no):
            lecturer_details.append(contact_no)
            break
        else:
            print("Invalid contact number. Please enter a 10-digit number.")
    
    while True:
        email = input("Enter lecturer's email: ")
        if is_valid_email(email):
            lecturer_details.append(email)
            break
        else:
            print("Invalid email. Please enter a valid email address.")
    
    while True:
        dob = input("Enter lecturer's DOB (yyyy-mm-dd): ")
        if is_valid_date_of_birth(dob):
            lecturer_details.append(dob)
            break
        else:
            print("Invalid date of birth. Please enter in the format yyyy-mm-dd.")
    
    
    age = calculate_age(dob)
    while True:
        try:
            # user_age = int(input(f"Enter lecturer's age (it should be {age-1}, {age}, or {age+1}): "))
            user_age = int(input(f"Enter lecturer's age: "))
        except ValueError:
            print("Invalid input. Age must be a number.")
            continue
        if user_age in [age - 1, age, age + 1]:
            lecturer_details.append(str(user_age))
            break
        else:
            print(f"The age is not accepted. It should be one of the following: {age-1}, {age}, or {age+1}.")

    
    while True:
        citizenship_no = input("Enter lecturer's citizenship number: ")
        if is_valid_citizenship_number(citizenship_no):
            lecturer_details.append(citizenship_no)
            break
        else:
            print("Invalid citizenship number. Please enter in the format XXX-XXX-XXXXX.")
    
    while True:
        id_number = input("Enter lecturer's ID: ")
        if is_valid_id(id_number):
            lecturer_details.append(id_number)
            break
        else:
            print("Invalid ID. Please enter a 3-digit ID.")
    
    while True:
        username = input("Enter lecturer's username: ")
        if is_valid_username(username):
            lecturer_details.append(username)
            break
        else:
            print("Invalid username. Please enter a username with at least 2 digits and no spaces.")
    
    while True:
        password = input("Enter lecturer's password: ")
        if is_valid_password(password):
            lecturer_details.append(password)
            break
        else:
            print("Invalid password. Please enter a password with at least one lowercase letter, one uppercase letter, one digit, and one symbol.")
    
    with open('lecturer_details.txt', 'a') as fp:
        content = ' '.join(lecturer_details) + "\n"
        fp.write(content)


def delete_lecturer():
    try:
        with open('lecturer_details.txt', 'r') as fp:
            content = fp.readlines()
            input_id = input('Enter the id of that lecturer:')
            boolean_value = False
            fp.seek(0)
            for i in fp:
                idd = i.split()[-3]
                if idd == input_id:
                    unwanted = i
                    boolean_value = True
                    break
            if not boolean_value:
                print('Id  of lecturer does not exist.')
                return
        with open('lecturer_details.txt', 'w') as gp:
            for j in content:
                if j != unwanted:
                    gp.write(f"{j}")
        print("Deleted successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")

def manage_lecturer():
    try:
        print('1. Add new lecturer')
        print('2. Delete lecturer')
        print('3. View lecturer')
        print('4. Exit')
        n = int(input('Enter your choice:'))
        if n == 1:
            add_new_lecturer()
            print('Lecturer added!')
        elif n == 2:
            delete_lecturer()
        elif n == 3:
            view_lecturer()
        elif n == 4:
            return
        else:
            print('Invalid choice')
    except Exception as e:
        print(f"An error occurred: {e}")


def add_course():
    while True:
        try:
            print('~'*15,'SUBJECTS','~'*15)
            subject_count = int(input('Enter the number of subjects (at least three):'))
        except ValueError:
            print('Invalid input, try again.')
            continue
        if subject_count >= 3:
            break
        print('~'*5,'SUBJECTS must be 3','~'*5)
        print('There should be at least three subjects')

    subjects = []
    topics = []
    for i in range(subject_count):
        print('~'*5,'SUBJECTS NAMES','~'*5)
        sub = input(f'Enter the name of subject  {i + 1}:')
        subjects.append(sub)
        while True:
            try:
                print('~'*5,'TOPICS NUMBERS','~'*5)
                topic_count = int(input(f'Enter the total number of topics in {sub}:'))
            except ValueError:
                print('Invalid input, try again')
                continue
            if topic_count >= 1:
                break
            print('~'*5,'SUBJECTS must be 1','~'*5)
            print("There should be at least one topic.")
        temp_list = []
        for j in range(topic_count):
            print('~'*5,'TOPICS NAME','~'*5)
            topic = input(f'Enter the name of topic {j + 1}:')
            temp_list.append(topic)
        topics.append(temp_list)
    with open('course.txt', 'w') as file:
        for sub_count, sub in enumerate(subjects):
            if not sub_count == 0:
                file.write('\n')
            file.write(f"{sub}:")
            for topic in topics[sub_count]:
                file.write(f"{topic},")

def delete_course():
    with open('course.txt', 'w') as fp:
        pass

def manage_course():
    print('1. Add Subjects and Topics')
    print('2. Delete Subjects and Topics')
    print('3. View Subjects and Topics')
    print('4. Exit')
    n = int(input('Enter numbers to perform specific tasks:'))
    if n == 1:
        add_course()
        print('Course added!')
    elif n == 2:
        delete_course()
        print('Course deleted!')
    elif n == 3:
        view_course()
    elif n == 4:
        pass
    else:
        print('Invalid choice')


def add_personnel():  
    personnel_details = []
    
    while True:
        first_name = input("Enter first name: ")
        if is_valid_name(first_name):
            personnel_details.append(first_name)
            break
        else:
            print("Invalid first name. Please enter alphabetic characters only.")
    
    while True:
        last_name = input("Enter last name: ")
        if is_valid_name(last_name):
            personnel_details.append(last_name)
            break
        else:
            print("Invalid last name. Please enter alphabetic characters only.")
    
    while True:
        address = input("Enter address: ")
        if is_valid_address(address):
            personnel_details.append(address)
            break
        else:
            print("Invalid address. Please enter an address containing both letters and numbers.")
    
    while True:
        contact_no = input("Enter contact no: ")
        if is_valid_contact_number(contact_no):
            personnel_details.append(contact_no)
            break
        else:
            print("Invalid contact number. Please enter a 10-digit number.")
    
    while True:
        username = input("Enter the username of personnel: ")
        if is_valid_username(username):
            personnel_details.append(username)
            break
        else:
            print("Invalid username. Please enter a username with at least 2 digits and no spaces.")
    
    while True:
        password = input("Enter the password of personnel: ")
        if is_valid_password(password):
            personnel_details.append(password)
            break
        else:
            print("Invalid password. Please enter a password with at least one lowercase letter, one uppercase letter, one digit, and one symbol.")
    
    while True:
        id_number = input("Enter the ID of Personnel: ")
        if is_valid_id(id_number):
            personnel_details.append(id_number)
            break
        else:
            print("Invalid ID. Please enter a 3-digit ID.")

    with open('personnel_details.txt', 'a') as fp:
        content = ' '.join(personnel_details) + "\n"
        fp.write(content)




def delete_personnel():
    try:
        with open('personnel_details.txt', 'r') as fp:
            content = fp.readlines()
            input_id = input('Enter the id of that personnel:')
            boolean_value = False
            updated_content = []
            for line in content:
                if line.split()[-1].strip() == input_id:
                    boolean_value = True
                else:
                    updated_content.append(line)
            if not boolean_value:
                print('Id of Personnel does not exist.')
                return
        with open('personnel_details.txt', 'w') as gp:
            gp.writelines(updated_content)
        print("Personnel deleted successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")

def view_personnel():
    with open('personnel_details.txt', 'r') as fp:
        ID = input('Enter the ID of that personnel: ')
        boolean_value = False
        for i in fp:
            if i.split()[-1] == ID:
                content = i
                boolean_value = True
                break
        if not boolean_value:
            print('ID does not exist.')
            return
        details = content.split()
        print(f'First name: {details[0]}')
        print(f'Last name: {details[1]}')
        print(f'Address: {details[2]}')
        print(f'Contact no: {details[3]}')
        print(f'Username: {details[4]}')
        print(f'Password: {details[5]}')
        print(f'ID: {details[6]}')


def manage_personnel():
    print('1. Add new personnel')
    print('2. Delete personnel')
    print('3. View personnel')
    print('4. Exit')
    n = int(input('Enter numbers (1,2,3,4):'))
    if n == 1:
        add_personnel()
        print('Personnel added!')
    elif n == 2:
        delete_personnel()
    elif n == 3:
        view_personnel()
    elif n == 4:
        pass
    else:
        print('Invalid choice')
